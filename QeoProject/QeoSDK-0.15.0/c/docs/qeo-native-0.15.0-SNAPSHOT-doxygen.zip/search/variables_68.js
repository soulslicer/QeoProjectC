var searchData=
[
  ['hardwareversion',['hardwareVersion',['../structqeo__platform__device__info.html#a8333856b46bd5d165a35a82364d877c8',1,'qeo_platform_device_info']]]
];
