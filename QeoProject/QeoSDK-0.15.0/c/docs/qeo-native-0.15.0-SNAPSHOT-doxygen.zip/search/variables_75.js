var searchData=
[
  ['upperid',['upperId',['../structqeo__platform__device__id.html#a1ec08dc415e99117250d1c4ea3bf3041',1,'qeo_platform_device_id']]],
  ['userfriendlyname',['userFriendlyName',['../structqeo__platform__device__info.html#adf69c314b8a46a220761f3589ce5893f',1,'qeo_platform_device_info']]]
];
