var searchData=
[
  ['productclass',['productClass',['../structqeo__platform__device__info.html#a27e694f2cb9c7d1a28f24dc9f437f88a',1,'qeo_platform_device_info']]]
];
