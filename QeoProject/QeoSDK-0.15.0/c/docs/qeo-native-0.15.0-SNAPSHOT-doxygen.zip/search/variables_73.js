var searchData=
[
  ['serialnumber',['serialNumber',['../structqeo__platform__device__info.html#a8d03381ac4e9fc5a032d2f0b68cde919',1,'qeo_platform_device_info']]],
  ['softwareversion',['softwareVersion',['../structqeo__platform__device__info.html#a9a55b6ea4db244e63786dd5ab84c1fc3',1,'qeo_platform_device_info']]]
];
