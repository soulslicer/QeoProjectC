var searchData=
[
  ['manufacturer',['manufacturer',['../structqeo__platform__device__info.html#ab0ca8c1bb631697dde67e929c14bb215',1,'qeo_platform_device_info']]],
  ['modelname',['modelName',['../structqeo__platform__device__info.html#aa3af579fcdba0f419f00b77ce0de8b41',1,'qeo_platform_device_info']]]
];
